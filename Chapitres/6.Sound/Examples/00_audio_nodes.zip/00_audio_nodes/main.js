import "./scss/style.scss";
import App from "./js/App";

window.onload = () => {
  new App();
};
